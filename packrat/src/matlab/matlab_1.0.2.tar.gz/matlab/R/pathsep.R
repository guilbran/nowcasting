###
### $Id: pathsep.R 48 2014-02-05 20:50:54Z plroebuck $
###
### Path separator for this platform.
###


##-----------------------------------------------------------------------------
pathsep <- .Platform$path.sep

