###
### $Id: filesep.R 48 2014-02-05 20:50:54Z plroebuck $
###
### Directory separator for this platform.
###


##-----------------------------------------------------------------------------
filesep <- .Platform$file.sep

