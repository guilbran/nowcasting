###
### $Id: ceil.R 48 2014-02-05 20:50:54Z plroebuck $
###
### Rounds to the nearest integer.
###


##-----------------------------------------------------------------------------
ceil <- function(x) {
    return(ceiling(x))
}

